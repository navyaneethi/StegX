// Initialize Firebase
var config = {
    apiKey: "AIzaSyCO3yjzquAAGOp3O09V1pr51yqysNALeo0",
        authDomain: "stegx-148c0.firebaseapp.com",
        projectId: "stegx-148c0",
        storageBucket: "stegx-148c0.appspot.com",
        messagingSenderId: "436928947016",
        appId: "1:436928947016:web:db0f12780156e74062897d",
        measurementId: "G-HVER2D87HQ"
  };
  firebase.initializeApp(config);